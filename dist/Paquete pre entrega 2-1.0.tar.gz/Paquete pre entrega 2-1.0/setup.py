from setuptools import setup

setup(
    name='Paquete pre entrega 2',
    version='1.0',
    description='Este es el primer paquete redistribuible',
    author='Ariel Godoy',
    author_email='arielgodoy@gmail.com',
    packages=['mi_paquete']
)